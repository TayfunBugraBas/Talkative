﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Talkative.Source.FireBase
{
    public static class Key
    {
        public const string webApiKey = "AIzaSyDC7sZn8kTjSnl0AsOwj_zf7vnYAQjs-is";
    }
}
