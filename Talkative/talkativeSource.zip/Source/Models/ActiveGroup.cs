﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Talkative.Source.Models
{
    public static class ActiveGroup
    {
       public static GroupModel Active_Group { get; set; }
    }
}
