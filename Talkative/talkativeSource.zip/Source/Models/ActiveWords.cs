﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Talkative.Source.Models
{
    public static class ActiveWords
    {
        public static List<WordModel> TalkingWords { get; set; }


    }
}
