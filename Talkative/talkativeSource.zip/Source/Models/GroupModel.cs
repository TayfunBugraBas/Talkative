﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Talkative.Source.Models
{
    public class GroupModel
    {
        public string GroupID { get; set; }
        public string groupUserID { get; set; }
        public string groupName { get; set; }
        public string groupIMGName { get; set; }

        public ImageSource ImageSource { get; set; }
    }
}
