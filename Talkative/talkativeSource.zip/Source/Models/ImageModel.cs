﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Talkative.Source.Models
{
    public class ImageModel
    {
        public string? byteBase64 { get; set; }
        public string? contentType { get; set; }

        public string? fileName { get; set; }


    }
}
