namespace Talkative.Source.Pages;

public partial class GroupCreatePage : ContentPage
{
	public GroupCreatePage()
	{
		InitializeComponent();
	}
    protected override bool OnBackButtonPressed()
    {
        
        return true;
    }
}