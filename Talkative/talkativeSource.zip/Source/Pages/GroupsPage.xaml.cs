namespace Talkative.Source.Pages;

public partial class GroupsPage : ContentPage
{
	public GroupsPage()
	{
		InitializeComponent();
	}
    protected override bool OnBackButtonPressed()
    {
        base.OnBackButtonPressed();
        return true;
    }

    


}